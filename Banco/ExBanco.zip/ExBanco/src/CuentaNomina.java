import java.util.ArrayList;

public class CuentaNomina {

       ArrayList<Movimientos> movimientos = new ArrayList<>();
        public double depositar(double cantidad){
            return 0; //Modificar el retorno
        }

        public double retirar(double cantidad){
            return 0; //Igual
        }
}
