import java.time.LocalDate;

public class CuentaInversion extends CuentaBancaria{
    private int plazo;
    private int intereses;

    public CuentaInversion(long numeroCuenta, double saldo, LocalDate fechaAlta, Cliente cliente) {
        super(numeroCuenta, saldo, fechaAlta, cliente);
    }

    public void proyectarInversion(){
        System.out.println("plazo: " + this.plazo);
        System.out.println("intereses: " + this.intereses);
    }
}
