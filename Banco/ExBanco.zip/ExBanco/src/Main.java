import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        int opc;
        Scanner lector = new Scanner(System.in);

        do {
            System.out.println("***** MENÚ PRINCIPAL *****");
            System.out.println("1.- Dar de alta una cuenta nomina");
            System.out.println("2.- Dar de alta una cuenta inversión");
            System.out.println("3.- Buscar cuenta por su numero de cuenta");
            System.out.println("4.- Listar cuentas de nomina");
            System.out.println("5.- Listar cuentas de inversión");
            opc = lector.nextInt();

            switch (opc){
                case 0:
                    System.out.println("Fin del programa....");
                    break;
                case 1:
                    System.out.println("Introduce el número de cuenta");
                    int noCuenta = lector.nextInt();
                    System.out.println("Introd");


            }

        }while (opc != 0);
    }
}
