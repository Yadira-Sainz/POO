public class Cliente {

    private String nombre;
    private String apellidos;
    private String domicilio;
    private String ciudad;
    private String telefono;

    public Cliente(String nombre, String apellidos, String domicilio, String ciudad, String telefono) {
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.domicilio = domicilio;
        this.ciudad = ciudad;
        this.telefono = telefono;
    }

}