import java.time.LocalDate;

public class CuentaBancaria {
    long numeroCuenta;

    public CuentaBancaria(long numeroCuenta, double saldo, LocalDate fechaAlta, Cliente cliente) {
        this.numeroCuenta = numeroCuenta;
        this.saldo = saldo;
        this.fechaAlta = fechaAlta;
        this.cliente = cliente;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    private double saldo;
    private LocalDate fechaAlta;
    private Cliente cliente;
}

